"use client";

import { useState, useEffect } from "react"
import { Waves, AlertCircle, CheckCircle, Bluetooth, Brain } from "lucide-react"
import { Button } from "@/components/ui/button"
import EmotionWheel from "../components/EmotionWheel"
import { useMuse } from "@/hooks/museHooks/useMuse"
import BrainwaveVisualizer from "../components/BrainwaveVisualizer"
import ElectrodeQualityIndicator from "../components/ElectrodeQualityIndicator"
import { useSessionData } from "@/hooks/museHooks/useSessionData"

interface TeamMember {
  id: string;
  name: string;
}

interface CalibrationProps {
  participant: TeamMember;
  onComplete: () => void;
}

export default function Calibration({ participant, onComplete }: CalibrationProps) {
  const {
    connectionStatus,
    signalQuality,
    eegData,
    electrodeQuality,
    connect,
    disconnect,
  } = useMuse();

  const { captureRestData } = useSessionData();

  // Estados de UI
  const [connectionPhase, setConnectionPhase] = useState(true);
  const [calibrationTime, setCalibrationTime] = useState(30);
  const [calibrationComplete, setCalibrationComplete] = useState(false);
  const [showNeutralPoint, setShowNeutralPoint] = useState(false);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);

  // Connect to Muse headset
  const handleConnect = async () => {
    setConnectError(null);
    try {
      if (!navigator.bluetooth) {
        setConnectError("Web Bluetooth is not supported in your browser. Please use Chrome, Edge, or Opera on desktop, or check browser compatibility.");
        return;
      }
      
      const success = await connect();
      if (!success) {
        setConnectError("Failed to connect to Muse. Please ensure the device is powered on and in pairing mode.");
      }
    } catch (error) {
      console.error("Error connecting to Muse:", error);
      setConnectError("An error occurred while connecting to Muse. Please try again.");
    }
  };

  // Start the calibration process
  const startCalibration = () => {
    setConnectionPhase(false);
    setIsCalibrating(true);
  };

  // Calibration timer
  useEffect(() => {
    if (!isCalibrating) return;
    
    const interval = setInterval(() => {
      setCalibrationTime((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          
          // 🔥 CAPTURAR DATOS DE REPOSO AQUÍ
          const restData = captureRestData();
          console.log('✅ Rest baseline captured during calibration:', restData);
          
          setCalibrationComplete(true);
          setShowNeutralPoint(true);
          setIsCalibrating(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isCalibrating, captureRestData]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Calibration - {participant.name}</h2>
      
      {connectionPhase ? (
        // Device Connection Phase
        <div>
          <p className="text-gray-600 mb-6">Please connect and position the Muse 2 headset to continue.</p>
          
          <div className="bg-white border rounded-lg p-6 mb-6">
            <div className="flex flex-col md:flex-row md:items-start gap-6">
              <div className="flex-shrink-0">
                <div className="w-44 h-44 relative">
                  <div className="absolute w-32 h-8 bg-gray-700 rounded-full top-20 left-6"></div>
                  <div className="absolute w-8 h-16 bg-gray-700 rounded-md left-6 top-12"></div>
                  <div className="absolute w-8 h-16 bg-gray-700 rounded-md right-6 top-12"></div>
                  
                  <div className="absolute w-4 h-4 rounded-full top-20 left-10 animate-pulse" 
                    style={{
                      backgroundColor: 
                        connectionStatus === "connected" ? "#10b981" : 
                        connectionStatus === "connecting" ? "#f59e0b" : 
                        connectionStatus === "error" ? "#ef4444" : "#6b7280"
                    }}
                  ></div>
                </div>
              </div>
              
              <div className="flex-grow">
                <h3 className="text-lg font-medium mb-3">Muse 2 Headset</h3>
                
                <div className="flex items-center mb-3">
                  <Bluetooth className="h-5 w-5 mr-2 text-blue-500" />
                  <span className="font-medium mr-2">Connection:</span>
                  <span className={`
                    px-2 py-1 rounded-full text-xs font-medium
                    ${connectionStatus === "disconnected" ? "bg-gray-100 text-gray-700" : ""}
                    ${connectionStatus === "connecting" ? "bg-yellow-100 text-yellow-700 animate-pulse" : ""}
                    ${connectionStatus === "connected" ? "bg-green-100 text-green-700" : ""}
                    ${connectionStatus === "error" ? "bg-red-100 text-red-700" : ""}
                  `}>
                    {connectionStatus === "disconnected" && "Not Connected"}
                    {connectionStatus === "connecting" && "Connecting..."}
                    {connectionStatus === "connected" && "Connected"}
                    {connectionStatus === "error" && "Connection Error"}
                  </span>
                </div>
                
                {connectionStatus === "connected" && (
                  <div className="flex items-center mb-3">
                    <Brain className="h-5 w-5 mr-2 text-purple-500" />
                    <span className="font-medium mr-2">Signal Quality:</span>
                    <span className={`
                      px-2 py-1 rounded-full text-xs font-medium
                      ${signalQuality === "poor" ? "bg-red-100 text-red-700" : ""}
                      ${signalQuality === "fair" ? "bg-yellow-100 text-yellow-700" : ""}
                      ${signalQuality === "good" ? "bg-green-100 text-green-700" : ""}
                      ${signalQuality === "excellent" ? "bg-emerald-100 text-emerald-700" : ""}
                    `}>
                      {signalQuality.charAt(0).toUpperCase() + signalQuality.slice(1)}
                    </span>
                  </div>
                )}
                
                {connectError && (
                  <div className="bg-red-50 border border-red-200 rounded-md p-3 flex mb-3">
                    <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-red-700">
                        {connectError}
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="mt-4">
                  {connectionStatus !== "connected" && (
                    <Button 
                      onClick={handleConnect} 
                      disabled={connectionStatus === "connecting"} 
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      {connectionStatus === "connecting" ? "Connecting..." : "Connect Muse Headset"}
                    </Button>
                  )}
                  
                  {connectionStatus === "connected" && (
                    <div className="flex space-x-3">
                      <Button 
                        onClick={() => disconnect()} 
                        variant="outline"
                      >
                        Disconnect
                      </Button>
                      
                      <Button 
                        onClick={startCalibration} 
                        disabled={signalQuality === "poor"} 
                        className="bg-[#4a2b4a] text-white hover:bg-[#694969]"
                      >
                        {signalQuality === "poor" 
                          ? "Improve Signal Quality First" 
                          : "Begin Calibration"}
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {connectionStatus === "connected" && (
              <>
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">EEG Signal Preview</h4>
                    <BrainwaveVisualizer eegData={eegData} />
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Electrode Signal Quality</h4>
                    <ElectrodeQualityIndicator electrodeQuality={electrodeQuality} />
                  </div>
                </div>
                
                {signalQuality !== "poor" && (
                  <div className="mt-6 pt-4 border-t">
                    <div className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Ready for Calibration</h4>
                        <p className="text-sm text-gray-600">
                          The Muse headset is properly connected and showing good signal quality. 
                          You're ready to begin the baseline calibration process.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      ) : (
        // Calibration Phase
        <div>
          <p className="text-gray-600 mb-6">Maintain a relaxed posture and breathe normally for {calibrationTime} seconds.</p>
          
          <div className="flex flex-col items-center mb-8">
            <div className="w-32 h-32 rounded-full bg-[#f0e6f0] flex items-center justify-center mb-4">
              <Waves className="h-16 w-16 text-[#4a2b4a]" />
            </div>

            <div className="text-4xl font-bold mb-4">{calibrationTime}s</div>
            
            {isCalibrating && (
              <div className="w-full max-w-md bg-white p-4 rounded-lg mb-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Live EEG Data</h4>
                <BrainwaveVisualizer eegData={eegData} />
              </div>
            )}

            {showNeutralPoint && (
              <div className="w-full max-w-md">
                <h3 className="text-lg font-medium mb-4 text-center">This is your neutral point</h3>
                <EmotionWheel showNeutralPoint={true} />
              </div>
            )}

            {calibrationComplete && (
              <Button className="bg-[#4a2b4a] text-white hover:bg-[#694969] mt-4" onClick={onComplete}>
                Start task evaluation
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
