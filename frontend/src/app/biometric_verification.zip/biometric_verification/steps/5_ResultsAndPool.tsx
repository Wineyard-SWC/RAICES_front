"use client"

import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { ParticipantResult } from "../page"
import type { Task } from "@/types/task"

interface TeamMember {
  id: string
  name: string
}

interface Sprint {
  team_members: TeamMember[]
}

interface ResultsAndPoolProps {
  participantResults: ParticipantResult[]
  replacementPool: string[]
  tasks: Task[]
  sprint: Sprint
  onNext: () => void
}

const emotionEmojis = {
  Happy: "😊",
  Focused: "🎯",
  Bored: "😴",
  Stressed: "😰",
}

export default function ResultsAndPool({
  participantResults,
  replacementPool,
  tasks,
  sprint,
  onNext,
}: ResultsAndPoolProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Results and Replacement Pool</h2>
      <p className="text-gray-600 mb-6">Review tasks that require reassignment due to complexity or stress.</p>

      <div className="mb-6">
        <h3 className="font-medium mb-3">Verification Summary</h3>
        <div className="border rounded-lg overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Member
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tasks evaluated
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Risk tasks
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Avg stress
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dominant emotion
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {participantResults.map((result) => {
                const participant = sprint.team_members.find((m) => m.id === result.participantId)
                const riskTasks = result.taskResults.filter((tr) => tr.isRisk).length

                return (
                  <tr key={result.participantId}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium">{participant?.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{result.taskResults.length}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          riskTasks > 0 ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                        }`}
                      >
                        {riskTasks}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden mr-2">
                          <div
                            className={`h-full ${
                              result.avgStress <= 0.3
                                ? "bg-green-500"
                                : result.avgStress <= 0.6
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${result.avgStress * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-xs">{Math.round(result.avgStress * 100)}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-lg">
                        {emotionEmojis[result.dominantEmotion as keyof typeof emotionEmojis]}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="font-medium mb-3">Replacement Pool ({replacementPool.length} tasks)</h3>
        {replacementPool.length === 0 ? (
          <div className="text-center py-8 border-2 border-dashed rounded-lg">
            <Check className="h-10 w-10 mx-auto text-green-500 mb-2" />
            <p className="text-gray-500">No risk tasks detected</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {replacementPool.map((taskId) => {
              const task = tasks.find((t) => t.id === taskId)
              if (!task) return null

              return (
                <div key={task.id} className="border rounded-lg p-3 bg-red-50">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium">{task.title}</h4>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        task.priority === "high"
                          ? "bg-red-100 text-red-800"
                          : task.priority === "medium"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                      }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                  <div className="flex items-center text-sm">
                    <span className="text-gray-500 mr-2">Assigned to:</span>
                    <span className="font-medium">
                      {sprint.team_members.find((m) => m.id === task.assignee_id)?.name || "Unassigned"}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <Button className="bg-[#4a2b4a] text-white hover:bg-[#694969]" onClick={onNext}>
          Continue to final review
        </Button>
      </div>
    </div>
  )
}
