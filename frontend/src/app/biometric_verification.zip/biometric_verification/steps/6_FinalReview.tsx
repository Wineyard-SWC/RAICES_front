"use client"

import { Check, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { ParticipantResult } from "../page"
import type { Task } from "@/types/task"

interface TeamMember {
  id: string
  name: string
}

interface Sprint {
  team_members: TeamMember[]
}

interface FinalReviewProps {
  participantResults: ParticipantResult[]
  replacementPool: string[]
  tasks: Task[]
  sprint: Sprint
  onBack: () => void
  onFinish: () => void
}

const emotionEmojis = {
  Happy: "😊",
  Focused: "🎯",
  Bored: "😴",
  Stressed: "😰",
}

export default function FinalReview({
  participantResults,
  replacementPool,
  tasks,
  sprint,
  onBack,
  onFinish,
}: FinalReviewProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Final Review</h2>
      <p className="text-gray-600 mb-6">Review and confirm changes to task assignments.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div>
          <h3 className="font-medium mb-3">Original Assignment</h3>
          <div className="border rounded-lg p-4 h-[400px] overflow-y-auto">
            {participantResults.map((result) => {
              const participant = sprint.team_members.find((m) => m.id === result.participantId)
              const memberTasks = tasks.filter((t) => t.assignee_id === participant?.id)

              return (
                <div key={result.participantId} className="mb-4">
                  <h4 className="font-medium mb-2">{participant?.name}</h4>
                  <div className="space-y-2">
                    {memberTasks.map((task) => {
                      const taskResult = result.taskResults.find((tr) => tr.taskId === task.id)

                      return (
                        <div
                          key={task.id}
                          className={`p-2 border rounded text-sm ${
                            replacementPool.includes(task.id) ? "bg-red-50 border-red-200" : "bg-gray-50"
                          }`}
                          title={
                            taskResult
                              ? `${taskResult.emotionBreakdown.Focused}% focused, ${taskResult.emotionBreakdown.Happy}% happy, ${taskResult.emotionBreakdown.Bored}% bored`
                              : ""
                          }
                        >
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{task.title}</div>
                            {taskResult && (
                              <span
                                className="text-lg"
                                title={`${taskResult.emotionBreakdown.Focused}% focused, ${taskResult.emotionBreakdown.Happy}% happy, ${taskResult.emotionBreakdown.Bored}% bored`}
                              >
                                {emotionEmojis[taskResult.dominantEmotion as keyof typeof emotionEmojis]}
                              </span>
                            )}
                          </div>
                          {replacementPool.includes(task.id) && (
                            <div className="text-xs text-red-600 flex items-center mt-1">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Requires reassignment
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div>
          <h3 className="font-medium mb-3">Reassignment Proposal</h3>
          <div className="border rounded-lg p-4 h-[400px] overflow-y-auto">
            {replacementPool.length === 0 ? (
              <div className="text-center py-8">
                <Check className="h-10 w-10 mx-auto text-green-500 mb-2" />
                <p className="text-gray-500">No changes required</p>
              </div>
            ) : (
              <div>
                <div className="mb-4">
                  <h4 className="font-medium text-red-600 mb-2">Unassigned Tasks</h4>
                  <div className="space-y-2">
                    {replacementPool.map((taskId) => {
                      const task = tasks.find((t) => t.id === taskId)
                      if (!task) return null

                      // Find emotion data from results
                      let emotionData = null
                      for (const result of participantResults) {
                        const taskResult = result.taskResults.find((tr) => tr.taskId === taskId)
                        if (taskResult) {
                          emotionData = taskResult
                          break
                        }
                      }

                      return (
                        <div
                          key={task.id}
                          className="p-2 border border-dashed border-gray-300 rounded text-sm bg-yellow-50"
                          title={
                            emotionData
                              ? `${emotionData.emotionBreakdown.Focused}% focused, ${emotionData.emotionBreakdown.Happy}% happy, ${emotionData.emotionBreakdown.Bored}% bored`
                              : ""
                          }
                        >
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{task.title}</div>
                            {emotionData && (
                              <span
                                className="text-lg"
                                title={`${emotionData.emotionBreakdown.Focused}% focused, ${emotionData.emotionBreakdown.Happy}% happy, ${emotionData.emotionBreakdown.Bored}% bored`}
                              >
                                {emotionEmojis[emotionData.dominantEmotion as keyof typeof emotionEmojis]}
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">Available for reassignment</div>
                        </div>
                      )
                    })}
                  </div>
                </div>

                <div className="text-xs text-gray-500 bg-blue-50 p-3 rounded">
                  💡 Suggestion: These tasks can be reassigned to other team members or divided into smaller subtasks.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button className="bg-[#4a2b4a] text-white hover:bg-[#694969]" onClick={onFinish}>
          Save changes and return to Sprint Planning
        </Button>
      </div>
    </div>
  )
}
