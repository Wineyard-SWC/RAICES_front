// utils/Muse2/museSingleton.ts
import { MuseService } from "./museService";

let singleton: MuseService | null = null;

export function getMuseService(): MuseService {
  if (!singleton) singleton = new MuseService();
  return singleton;
}
