import { useSession } from "next-auth/react"
import { useMuse }   from "./useMuse"
import { useCallback, useState }   from "react"

export function useSessionData() {
  const { data: session } = useSession();
  const { pause, resume, drainRawData } = useMuse();
  const [restBaseline, setRest] = useState<{eeg:number[];ppg:number[];hr:number[]} | null>(null);
  const [isSubmitting, setSubmitting] = useState(false);

  const captureRestData = useCallback(() => {
    console.log("🔍 captureRestData: iniciando captura");
    
    // Pausa la acumulación de datos
    pause();
    console.log("🔍 captureRestData: pausada la captura");
    
    // Obtiene y drena los datos acumulados
    const raw = drainRawData();
    console.log("🔍 captureRestData: datos drenados", { 
      eeg: raw.eeg?.length || 0, 
      ppg: raw.ppg?.length || 0, 
      hr: raw.hr?.length || 0 
    });
    
    // Almacena el baseline
    setRest(raw);
    
    // Reanuda la captura para siguientes tareas
    resume();
    console.log("🔍 captureRestData: captura reanudada");
    
    return raw;
  }, [pause, resume, drainRawData]);

  const captureTaskData = useCallback((id:string,name:string,rating:number,explanation?:string)=>{
    pause();
    const raw = drainRawData();
    resume();
    return { taskId:id, taskName:name, eeg:raw.eeg, ppg:raw.ppg, hr:raw.hr, userRating:rating, explanation };
  }, [pause, resume, drainRawData]);

  const submitParticipantSession = useCallback(async(participantId:string,tasks:any[])=>{
    if(!session?.user?.email || !restBaseline) return false;
    setSubmitting(true);
    try{
      const sessionId=`session_${Date.now()}_${participantId}`;
      const payload={ sessionId, userFirebaseId:session.user.email, participantId, contextType:"task_evaluation", restData:restBaseline, tasks };
      const res = await fetch("/api/process_session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
      return res.ok;
    }finally{ setSubmitting(false); }
  }, [session, restBaseline]);

  return { captureRestData, captureTaskData, submitParticipantSession, isSubmitting, restBaseline };
}
