import { MuseService, type ConnectionStatus,
  type SignalQuality, } from "@/utils/Muse2/museService"
import { getMuseService } from "@/utils/Muse2/museSingleton";
import { useEffect, useRef, useState, useCallback } from "react"

export function useMuse() {
  // Singleton pattern to ensure only one instance of MuseService is created
  const svc = getMuseService();
  const serviceRef = useRef<MuseService | null>(null);
  if (!serviceRef.current) serviceRef.current = svc;

  const [connectionStatus, setStatus]   = useState<ConnectionStatus>("disconnected")
  const [signalQuality,   setQuality]   = useState<SignalQuality>("poor")
  const [eegData,         setEEG]       = useState<number[]>([])
  const [ppgData,         setPPG]       = useState<number[]>([])
  const [hrData,          setHR]        = useState<number[]>([])
  const [electrodes,      setElect]     = useState<number[]>([0, 0, 0, 0])

  useEffect(() => {
    const s1 = svc.connectionStatus$.subscribe(setStatus)
    const s2 = svc.signalQuality$.subscribe(setQuality)
    const s3 = svc.eegData$.subscribe(setEEG)
    const s4 = svc.ppgData$.subscribe(setPPG)
    const s5 = svc.hrData$.subscribe(setHR)
    const s6 = svc.electrodeQuality$.subscribe(setElect)
    return () => { s1.unsubscribe(); s2.unsubscribe(); s3.unsubscribe(); s4.unsubscribe(); s5.unsubscribe(); s6.unsubscribe() }
  }, [svc])

  /* Public API (memo) */
  const connect       = useCallback(() => svc.connect(),  [svc])
  const disconnect    = useCallback(() => svc.disconnect(), [svc])
  const pause         = useCallback(() => svc.pause(),    [svc])
  const resume        = useCallback(() => svc.resume(),   [svc])
  const drainRawData  = useCallback(() => svc.drainRawData(), [svc])

  return { connectionStatus, signalQuality, eegData, ppgData, hrData, electrodes,
           connect, disconnect, pause, resume, drainRawData }
}